// Element references
const gameBoard = document.getElementById('game-board');
const timeLeftEl = document.getElementById('time-left');
const scoreEl = document.getElementById('score');
const matchesEl = document.getElementById('matches');
const restartBtn = document.querySelector('.restart-btn');

// Game variables
let cards = [];
let flippedCards = [];
let matchedPairs = 0;
let score = 0;
let timeLeft = 60;
let timer;
let canFlip = true;

// Kartu data - menggunakan file A.jpg sampai H.jpg
const cardData = [
    { name: 'A', img: './img/A.jpg' },
    { name: 'B', img: './img/B.jpg' },
    { name: 'C', img: './img/C.jpg' },
    { name: 'D', img: './img/D.jpg' },
    { name: 'E', img: './img/E.jpg' },
    { name: 'F', img: './img/F.jpg' },
    { name: 'G', img: './img/G.jpg' },
    { name: 'H', img: './img/H.jpg' }
];

// Initialize game
function initGame() {
    clearInterval(timer);
    gameBoard.innerHTML = '';
    flippedCards = [];
    matchedPairs = 0;
    score = 0;
    timeLeft = 60;
    canFlip = true;
    
    updateDisplay();
    createCards();
    startTimer();
}

// Create cards
function createCards() {
    // Duplicate cards untuk membuat pasangan
    const gameCards = [...cardData, ...cardData];
    
    // Acak kartu
    gameCards.sort(() => Math.random() - 0.5);
    
    gameCards.forEach((card, index) => {
        const cardElement = document.createElement('div');
        cardElement.className = 'card';
        cardElement.dataset.name = card.name;
        
        cardElement.innerHTML = `
            <div class="card-back"></div>
            <div class="card-front">
                <img src="${card.img}" alt="${card.name}" onerror="this.style.display='none'">
            </div>
        `;
        
        cardElement.addEventListener('click', () => flipCard(cardElement));
        gameBoard.appendChild(cardElement);
    });
}

// Flip card function
function flipCard(card) {
    if (!canFlip || card.classList.contains('flipped') || flippedCards.length >= 2) {
        return;
    }
    
    card.classList.add('flipped');
    flippedCards.push(card);
    
    if (flippedCards.length === 2) {
        canFlip = false;
        setTimeout(checkMatch, 500);
    }
}

// Check for match
function checkMatch() {
    const [card1, card2] = flippedCards;
    const isMatch = card1.dataset.name === card2.dataset.name;
    
    if (isMatch) {
        card1.classList.add('matched');
        card2.classList.add('matched');
        matchedPairs++;
        score += 10;
        
        if (matchedPairs === cardData.length) {
            endGame(true);
        }
    } else {
        setTimeout(() => {
            card1.classList.remove('flipped');
            card2.classList.remove('flipped');
        }, 1000);
        score = Math.max(0, score - 2);
    }
    
    flippedCards = [];
    canFlip = true;
    updateDisplay();
}

// Timer function
function startTimer() {
    timer = setInterval(() => {
        timeLeft--;
        updateDisplay();
        
        if (timeLeft <= 0) {
            endGame(false);
        }
    }, 1000);
}

// Update display
function updateDisplay() {
    timeLeftEl.textContent = `${timeLeft}s`;
    scoreEl.textContent = score;
    matchesEl.textContent = matchedPairs;
}

// End game
function endGame(isWin) {
    clearInterval(timer);
    canFlip = false;
    
    setTimeout(() => {
        if (isWin) {
            alert(`Selamat! Anda menang dengan skor: ${score}`);
        } else {
            alert(`Waktu habis! Skor akhir: ${score}`);
        }
    }, 500);
}

// Event listeners
restartBtn.addEventListener('click', initGame);

// Start the game
initGame();